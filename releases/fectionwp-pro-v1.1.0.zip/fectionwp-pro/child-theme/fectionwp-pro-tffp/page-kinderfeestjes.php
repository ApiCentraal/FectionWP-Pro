<?php
/**
 * Template Name: Kinderfeestjes (TFFP)
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<?php
get_template_part( 'template-parts/tffp/kinderfeestjes' );
?>

<?php
get_footer();
