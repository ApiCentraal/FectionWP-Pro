<?php
/**
 * Template Name: Contact (TFFP)
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<?php
get_template_part( 'template-parts/tffp/contact' );
?>

<?php
get_footer();
