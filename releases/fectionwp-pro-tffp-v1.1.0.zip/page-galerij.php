<?php
/**
 * Template Name: Galerij (TFFP)
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<?php
get_template_part( 'template-parts/tffp/galerij' );
?>

<?php
get_footer();
