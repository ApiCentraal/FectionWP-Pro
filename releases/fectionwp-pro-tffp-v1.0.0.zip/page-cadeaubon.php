<?php
/**
 * Template Name: Cadeaubon (TFFP)
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<?php
get_template_part( 'template-parts/tffp/cadeaubon' );
?>

<?php
get_footer();
