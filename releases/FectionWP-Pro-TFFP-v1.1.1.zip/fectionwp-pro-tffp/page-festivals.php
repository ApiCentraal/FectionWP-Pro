<?php
/**
 * Template Name: Festivals (TFFP)
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<?php
get_template_part( 'template-parts/tffp/festivals' );
?>

<?php
get_footer();
